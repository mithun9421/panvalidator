package com.journaldev.spring.controller;

public class EmpRestURIConstants {
	
	public static final String PANVALIDATOR = "/rest/validate/{panID}";
}
