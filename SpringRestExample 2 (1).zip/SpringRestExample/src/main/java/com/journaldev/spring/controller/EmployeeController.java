package com.journaldev.spring.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.journaldev.spring.model.CreditCard;
import com.journaldev.spring.model.Employee;
import com.utils.*;
/**
 * Handles requests for the Employee service.
 */
@Controller
public class EmployeeController {
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@RequestMapping(value = EmpRestURIConstants.PANVALIDATOR, method = RequestMethod.GET)
	public @ResponseBody String createEmployee(@PathVariable("panID") String panID) {
		String result = "";
		logger.info("Start createEmployee.");
		Boolean isValidPanCard = validatePANCard(panID);
		if(isValidPanCard == false) {
			return "Please enter the valid pan card";
		}
		else {
			//add pan cards of your wish
			CreditCard TcreditCard = new CreditCard("PPASDPASD", 765);
	        Transaction transaction = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            // start a transaction
	            transaction = session.beginTransaction();
	            // save the student objects
	            session.save(TcreditCard);
	            // commit transaction
	            transaction.commit();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	 
	        try  {
	        	Session session = HibernateUtil.getSessionFactory().openSession();
	            List < CreditCard > creditCardResult = session.createQuery("from CreditCard", CreditCard.class).list();
	    		ListIterator<CreditCard> listIterator = creditCardResult.listIterator();
	    		while(listIterator.hasNext()){
	    			System.out.println();
	    			CreditCard ccObj = listIterator.next();
	    			System.out.println(ccObj.getCreditScore() + " " + ccObj.getPanNumber());
	    			if(ccObj.getPanNumber().equalsIgnoreCase(panID)  && (ccObj.getCreditScore() > 750)) {
	    				return "You are eligible for Credit card";
	    			}
	    			else if(ccObj.getCreditScore() < 750) {
	    				return "CIBIL SCORE TOO LOW";
	    			}
	    			else if(!ccObj.getPanNumber().equalsIgnoreCase(panID)) {
	    				return "No matching Pan card in put inventory";
	    			}
	    		}
	        } catch (Exception e) {
	                e.printStackTrace();
	        }
		}
		return "Please try again";
	}
	
	public static boolean validatePANCard(String panID) {
		Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");
		Boolean res = false;
		Matcher matcher = pattern.matcher(panID);
		// Check if pattern matches 
		if (matcher.matches()) {
		  System.out.println("Matching" + "Yes");
		  res = true;
		}   
		return res;
	}
	
}
