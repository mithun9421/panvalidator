package com.journaldev.spring.model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CreditCard")
public class CreditCard {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
	private int Id;
	
	@Column(name = "pan_number")
	private String panNumber;
	
	@Column(name = "credit_score") 
	private int creditScore;

	public CreditCard(int id, String panNumber, int creditScore) {
		super();
		Id = id;
		this.panNumber = panNumber;
		this.creditScore = creditScore;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		this.Id = id;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public int getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}
	
	public CreditCard(String panNumber, int i) {
		this.panNumber = panNumber;
		this.creditScore = i;
	}
	
	public CreditCard() {
		
	}
	
}
